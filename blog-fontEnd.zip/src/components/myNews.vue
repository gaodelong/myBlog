<template>
    <div class="news"> 
        <div class="head">
            <h2>My Notes</h2>
            <p>记录代码的点点滴滴</p>
        </div>
        <div class="content">
            <el-row :gutter="20" class="articleList">
                <el-col :xs="12" :sm="12" :md="8" :lg="6" :xl="4" v-for="(o,index) in articleTotals" :key="index">
                    <a class="card">
                        <div class="image">
                            <img src="http://ouvwmmux2.bkt.clouddn.com/js.jpg" alt="">
                        </div>
                        <div class="box">
                            <p class="article_title">Vue入门学习...</p>
                            <p class="date">{{currentDate}}</p>
                            <p class="description">Vue是一套用于构建用户界面的渐进式框架...</p>
                            <p class="article_foot">
                                <span class="tag">
                                    <i class="tag_type tag_js">JS</i>
                                </span>
                                <span class="read_more fr">阅读全文</span>
                            </p>
                        </div>
                    </a>
                </el-col>
            </el-row>
            <div class="foot">
                <el-pagination
                    layout="prev, pager, next"
                    :total="1000">
                </el-pagination>
            </div>
        </div>
    </div>
</template>

<script>
export default {
    data: function() {	
        return {
            // 文章总条数
            articleTotals : 8,
        }
    },
    computed: {
        // 文章当前时间
        currentDate:  function (){ 
            return new Date("yyyy,mth,dd")
        }
    },
    methods: {
        
    }
}
</script>

<style scoped>
    .news{
        padding: 0 4.16666em;
    }
    .news .head{
        padding-top: 3em;
    }
    .news .head h2{
        font-size: 4em;
        color: #42B8F1;
        user-select: none;
    }
    .news .head p{
        margin-top: 0.5em;
        font-size: 1.28em;
        letter-spacing: 0.1em;
    }
    .news .content{
        margin-top: 3em;
    }
    .news .foot{
        text-align: right;
    }
    .news .content .el-col{
        margin-bottom:2.1em;
    }
    .news .content .el-col a.card{
        display: block;
        width: 100%;
        height: 100%;
        box-shadow: 0 2px 20px 2px rgba(0,0,0,0.12);
        transition: box-shadow 500ms ease-in-out, transform 500ms ease-in-out;
    }
    .news .content .el-col a.card:hover{
        box-shadow: 0 10px 20px 3px rgba(0,0,0,0.18);
        -ms-transform: scale(1.05);
        transform: scale(1.005);
    }
    .news .content .el-col a.card .image{
        border:none;
        border-radius: .28571429rem .28571429rem 0 0!important;
    }
    .news .content .el-col a.card .image img{
        display: block;
        height: auto;
        /* height: 130px; */
        width: 100%;
        max-width: 100%;
        max-height: 100%;
        border-radius: inherit;
    }  
    .news .content .el-col a.card .box {
        -webkit-box-flex: 1;
        -ms-flex-positive: 1;
        flex-grow: 1;
        border: none;
        /* border: 1px solid #D4D4D5; */
        border-top-color:rgba(34,36,38,.1);
        border-radius: 0 0 .28571429rem .28571429rem!important;
        color:rgba(0,0,0,.85);
        background: 0 0;
        margin: 0;
        padding: 1em 1em;
        box-shadow: none;
        font-size: 1em;
        border-radius: 0;
        text-align: left;
    }
    .news .content .el-col a.card .box p{
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
    }
    .news .content .el-col a.card .box p.article_title{
        width: 90%;
        font-weight: 700;
        font-size: 1.38571429em;
        margin-top: -.21425em;
        line-height: 1.38571429em;
    }
    .news .content .el-col a.card .box p.date{
        margin-top: 0.3em;
        font-size: 1em;
        color: #656565;
    }
    .news .content .el-col a.card .box p.description{
        width: 100%;
        margin-top: 0.5em;
        font-size: 1.2em;
        color: rgba(0,0,0,.7);
    }
    .news .content .el-col a.card .box p.article_foot{
        padding-top: 1em;
    }
    .news .content .el-col a.card .box p.article_foot span{
        display: inline-block;
        vertical-align: -webkit-baseline-middle;
        font-size: 1.2em;
    }    
    .news .content .el-col a.card .box p.article_foot .tag_type{
        display: inline-block;
        padding: 0.07em 0.597em;
        border-radius: 0.2em;
        color: #fff;
    }
    /* js 标签 */
    .news .content .el-col a.card .box p.article_foot .tag_type.tag_js{
        background: #40b0ff;
    } 
    /* css 标签 */
    .news .content .el-col a.card .box p.article_foot .tag_type.tag_css{
        background: #ffa900;
    }    
    /* html 标签 */
    .news .content .el-col a.card .box p.article_foot .tag_type.tag_html{
        background: #6ebd6b;
    }    
    /* vue 标签 */    
    .news .content .el-col a.card .box p.article_foot .tag_type.tag_vue{
        background: #00a99d;
    }   
    /*webpack 标签 */     
    .news .content .el-col a.card .box p.article_foot .tag_type.tag_webpack{
        background: #b062a3;
    }    
    /* 转载 标签 */
    .news .content .el-col a.card .box p.article_foot .tag_type.tag_reprint {
        background: #00528e;
    }  
    /* 其他 标签 */
    .news .content .el-col a.card .box p.article_foot .tag_type.tag_other{
        background: #a68369;
    }    
    .news .content .el-col a.card .box p.article_foot .read_more{
        color: #737373;
    }
    .news .content .el-col a.card .box p.article_foot .read_more:hover,
    .news .content .el-col a.card .box p.article_foot .read_more:active{
        text-decoration: underline
    
    }
</style>