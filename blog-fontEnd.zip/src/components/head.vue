<template>
    <el-header>
        
    </el-header>
</template>

<script>
export default {
    
    data: function() {	
        return {}
    },
    methods: {}
}
</script>

<style scoped>
    
</style>